/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main ()
{
    int n = 0, i = 0, l1 = 0, l2 = 0, temp = 0;
    printf ("Enter the size of the array\n");
    scanf ("%d", &n);
    int array[n];
    printf ("Enter the elements\n");
    for (i = 0; i < n; i++)
    {
        scanf ("%d", &array[i]);
    }
    printf ("The array elements are : \n");
    for (i = 0; i < n; i++)
    {
        printf ("%d\t", array[i]);
    }
    printf ("\n");
    l1 = array[0];
    l2 = array[1];
    if (l1 < l2)
    {
        temp = l1;
        l1 = l2;
        l2 = temp;
    }
    for (int i = 2; i < n; i++)
    {
        if (array[i] > l1)
        {
            l2 = l1;
            l1 = array[i];
        }
        else if (array[i] > l2 && array[i] != l1)
        {
            l2 = array[i];
        }
    }
    printf ("The FIRST LARGEST = %d\n", l1);
    printf ("THE SECOND LARGEST = %d\n", l2);
    return 0;
}