/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void main()
{
    long int ARR[10], OAR[10], EAR[10];
    int i, j = 0, k = 0, n;
    printf("Enter the size of array AR ");
    scanf("%d", &n);
    printf("Enter the elements of the array ");
    for (i = 0; i < n; i++)
    {
        scanf("%ld", &ARR[i]);
        fflush(stdin);
    }
    for (i = 0; i < n; i++)
    {
        (ARR[i] % 2 == 0);
    {
        EAR[j] = ARR[i];
        j++;
        OAR[k] = ARR[i];
        k++;
    }
    }
    printf("The elements of OAR are n");
    for (i = 0; i < k; i++)
    {
        printf("%ld", OAR[i]);
    }
    printf("The elements of EAR are n");
    for (i = 0; i < j; i++)
    {
        printf("%ld", EAR[i]);
    }
}
